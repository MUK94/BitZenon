<title><?php echo e($title); ?> | <?php echo e(config('app.name')); ?> </title>
<?php $__env->startSection('content'); ?>
    <section class="content-layout header-container">
        <div class="landing pt-6">
            <div class="left">
                <?php $__currentLoopData = $heroSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="hero-container">
                        <img src="<?php echo e(asset('storage/' . $hero->image)); ?>" alt="<?php echo e($hero->title); ?>">
                        <button class="btn-angle-down" onclick="scrollToBottom()">
                            <i class="fa-solid fa-angle-down"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="right sidebar">
                <div class="slider">
                    <?php $__currentLoopData = $mostPopular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="slide">
                            <div class="box">
                                <div class="tags pb-2">
                                    <a
                                        href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                                </div>
                                <a href="/blog/<?php echo e($article->slug); ?>">
                                    <div class="side-articles side-slider">
                                        <h3><?php echo e($article->title); ?></h3>
                                        <p>
                                            <?php echo Str::limit($article->description, 50, '...'); ?>
                                        </p>
                                        <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>"
                                            alt="<?php echo e($article->title); ?>">
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- silder  buttons and dots -->
                    <button aria-label="none" class="slider__btn slider__btn--left"><i
                            class="fa-solid fa-angle-left"></i></button>
                    <button aria-label="none" class="slider__btn slider__btn--right"><i
                            class="fa-solid fa-angle-right"></i></button>

                    <div class="dots mt-2"></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-container content-layout scrollable-content">
        <div class="title">
            <h2>About <span>me</span></h2>
        </div>
        <div class="about-container pt-8 mb-12">
            <?php $__currentLoopData = $aboutSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pt-8 pb-16 w-full flex justify-between items-center gap-8 relative">
                    <img class="w-1/2 h-96 object-cover" src="<?php echo e(asset('storage/' . $about->image)); ?>"
                        alt="<?php echo e($about->name); ?>">
                    <div class="w-1/2 flex flex-col">
                        <div class="flex flex-col">
                            <span><?php echo e($about->name); ?></span>
                            <div class="about-social-links mb-6">
                                <p class="custom-blue-color-1 text-3xl font-bold mb-1"><?php echo e($about->title); ?></p>
                                <?php echo $__env->make('inc.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <p class="mb-2 mr-6">
                                <?php echo e($about->description); ?>

                            </p>
                            <div class="btns flex justify-around gap-2">
                                <button class="btn btn-primary  about-btn my-4"><a class="px-2"
                                        href="https://linkedin.com/in/thierno-dev">Read
                                        More <i class="ml-1 fa-solid fa-arrow-up-right-from-square"></i></a></button>
                                <button class="btn btn-secondary  about-btn my-4"><a class="px-2" href="#">Download
                                        CV <i class="ml-1 fa-solid fa-cloud-arrow-down"></i></a></button>
                                <button class="btn btn-tertiary  about-btn my-4"><a class="px-2" href="#">Call me <i
                                            class="mb-2 text-3xl text-white fa-solid fa-phone"></i></a></button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $__env->make('inc.about-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
    </section>

    <section class="section-container mb-12">
        <div class="content-layout">
            <div class="title">
                <h2>My<span> Services</span></h2>
            </div>
            <div class="service-desc text-center">
                <p class="px-4 italic text-xl">
                    "Designed for projects of any scope and complexity, Build and enhance your web presence with tailored
                    solutions. Automate your business processes for efficiency, Turn your data into actionable insights."
                </p>
            </div>
            <?php echo $__env->make('inc.services-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('inc.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>

    <section class="section-container content-layout">
        <div class="title">
            <h2> Latest <span>Posts</span></h2>
        </div>
        <div class="container posts">

            <?php echo $__env->make('inc.latest-posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/home.blade.php ENDPATH**/ ?>
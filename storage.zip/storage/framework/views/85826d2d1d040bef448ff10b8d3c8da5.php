<title><?php echo e($title); ?> | Admin</title>
<?php $__env->startSection('content'); ?>
    <div class="flex items-center flex-col my-8 mx-4">
        <h1 class="text-xl font-bold mb-4"><?php echo e($title); ?></h1>
        <form method="POST" action="<?php echo e(route('hero-section.store')); ?>" enctype="multipart/form-data"
            class="w-full flex flex-col justify-betwen gap-2 bg-white shadow-sm rounded px-4 pt-6 pb-8 m-4">
            <?php echo csrf_field(); ?>

            <div class="my-4 flex justify-between gap-3">
                <div class="mb-1">
                    <label for="title" class="block mb-1">Titre</label>
                    <input type="text" name="title" required id="title"
                        class="font-light mt-1 p-2 block focus:outline-none focus:ring-2 focus:ring-blue-700 border border-gray-300 rounded-md w-80">
                </div>

                <div class="mb-1">
                    <label for="cover_image" class="block mb-1">Image </label>
                    <input type="file" name="image" id="cover_image"
                        class="h-12 px-2 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-700"
                        required>
                </div>
            </div>
            <div>
                <button type="submit"
                    class="px-4 py-2 text-white custom-blue-color  rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-600">
                    Save
                </button>
            </div>
        </form>

        
        <div class="py-6 my-6 w-full">
            <h2 class="font-bold text-center text-xl">Current Hero</h2>
            <div class="flex flex-col mt-8">
                <div class="py-2 -my-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
                    <div
                        class="inline-block min-w-full bg-white overflow-hidden align-middle border-b border-gray-200 shadow-sm rounded">
                        <table class="min-w-full">
                            <thead>
                                <tr>
                                    <th
                                        class="px-6 py-3 text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
                                        ID
                                    </th>
                                    <th
                                        class="px-6 py-3 text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
                                        Title
                                    </th>
                                    <th
                                        class="px-6 py-3 text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
                                        Image
                                    </th>

                                    <th class="px-6 py-3 border-b border-gray-200 bg-gray-50"></th>
                                    <th
                                        class="px-6 py-3 text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white">
                                <?php $__currentLoopData = $heroSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                                            <div class="flex items-center">
                                                <div class="">
                                                    <div class="text-sm font-medium leading-5 text-gray-900">
                                                        <?php echo e($hero->id); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                                            <div class="text-sm leading-5 text-gray-900">
                                                <?php echo e($hero->title); ?>

                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                                            <div class="text-sm leading-5 text-gray-900">
                                                <img src="<?php echo e(asset('storage/' . $hero->image)); ?>" alt="<?php echo e($hero->title); ?>"
                                                    class="w-24 h-16">
                                            </div>
                                        </td>

													 <td class="px-3 py-4 whitespace-no-wrap border-b border-gray-200"></td>

                                        <td
                                            class="pr-12 py-4 text-sm font-medium leading-5 text-right whitespace-no-wrap border-b border-gray-200">
                                            <a href="<?php echo e(route('hero-section.edit', $hero->id)); ?>"
                                                class="text-green-600 hover:text-green-900">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/admin/hero-section/index.blade.php ENDPATH**/ ?>
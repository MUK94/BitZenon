<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon-pro.png')); ?>">


<script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

<!-- Fonts -->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Lexend+Deca:wght@200;300;500;600;700&family=Roboto+Mono:wght@100;300;400;500;700&display=swap"
    rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Space+Grotesk:wght@300..700&display=swap"
    rel="stylesheet">


<link rel="stylesheet" href="<?php echo e(asset('css/_variables.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/head.blade.php ENDPATH**/ ?>
<div class="social">
	<a href="https://linkedin.com/in/thierno-dev" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
	<a href="#"><i class="fa-brands fa-x-twitter"></i></a>
	<a href="#"><i class="fa-brands fa-youtube-square"></i></a>
	<a href="#"><i class="fa-brands fa-facebook"></i></a>
	<a href="#"><i class="fa-brands fa-github"></i></a>
</div><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/social-media.blade.php ENDPATH**/ ?>
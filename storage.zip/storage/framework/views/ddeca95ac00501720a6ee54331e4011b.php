<footer class="flex text-gray-600 font-light items-end justify-center bottom-0 my-2 py-2">
    © 2020 - 2024 <?php echo e(config('app.name')); ?> All Rights Reserved
</footer>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('js/graphs.js')); ?>"></script>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/admin-footer.blade.php ENDPATH**/ ?>
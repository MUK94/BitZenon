<footer class="footer pt-8">
    <div class="container content-layout">
        <div class="row py-12">
            <div class="col">
                <div class="box ">
                    <p class="custom-blue-color-1 mb-2 font-semibold text-5xl"><?php echo e(config('app.name')); ?></p>
                    <p class="mb-6 text-white">Empowering your Digital Journey with Bright Solutions!</p>
                    <div class="newsletter">
                        
                        <div class="company-address mt-8">
                            <ul class="social">
                                <li><i class="fa-solid fa-map-location"></i> Mannheim, Germany</li>
                                <li><i class="fa-solid fa-phone"></i> +49 1784608200</li>
                                <li><i class="fa-solid fa-envelope-open-text"></i> service@badrio.dev</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col ">
                <ul class="box">
                    <h3>Main Services</h3>
                    <li class="footer-link"><a href="/services" target="_blank">Process Automation</a></li>
                    <li class="footer-link"><a href="/services" target="_blank">Dataviz & Analytics</a></li>
                    <li class="footer-link"><a href="/services" target="_blank">Consultation & Training</a></li>
                    <li class="footer-link"><a href="/services" target="_blank">Full-Stack Web Development</a></li>
                    <li class="footer-link"><a href="/services" target="_blank">Business Apps Development </a></li>
                </ul>
            </div>
            <div class="col ">
                <ul class="box">
                    <h3>Categories</h3>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/categories/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="container content-layout">
        <div class="copyright border-t border-gray-700">
            <div class="text">
                <?php echo e(config('app.name')); ?> © 2024 All Rights Reserved
            </div>
            <?php echo $__env->make('inc.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</footer>

<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('js/graphs.js')); ?>"></script>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/footer.blade.php ENDPATH**/ ?>
<title><?php echo e($title); ?> | BitZenon </title>
<?php $__env->startSection('content'); ?>
    <div class="content-layout">
        <div class="container article-post">
            <div class="headings">
                <h2>About <span>Us</span></h2>
            </div>
            <div class="contact-container pt-8 mb-12">
                <?php $__currentLoopData = $aboutSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <div class="pt-8 pb-16 w-full flex justify-between items-center gap-12 relative">
						<img class="w-1/2 h-96 object-cover" src="<?php echo e(asset('storage/' . $about->image)); ?>" alt="<?php echo e($about->name); ?>">
						<div class="w-1/2 flex flex-col">
							<div class="flex flex-col">
								<span><?php echo e($about->name); ?></span>
								<div class="about-social-links mb-6">
									<h3 class="custom-blue-color-1 text-4xl "><?php echo e($about->title); ?></h3>
									<?php echo $__env->make('inc.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</div>
								  <p class="mb-2 mr-6">
										<?php echo e($about->description); ?>

								  </p>
								  <div class="btns flex gap-2">
										<button class="btn btn-primary about-btn my-4">Hire Me</button>
										<button class="btn btn-secondary about-btn my-4">Download CV</button>
										<button class="btn btn-secondary about-btn my-4">Book a Meeting</button>
								  </div>
							 </div>
						</div>
				  </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('inc.about-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/pages/about.blade.php ENDPATH**/ ?>
<div class="latest-container">
    <div class="first-row flex justify-between gap-4">
        <?php $__currentLoopData = $latestArticles->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="old-post shadow-sm rounded-lg">
                <a href="/blog/<?php echo e($article->slug); ?>">
                    <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>" alt="<?php echo e($article->title); ?>" class="max-w-full img-box">
                </a>
                <div class="description mt-2">
                    <div class="flex justify-between">
                        <div class="old-tag px-3">
                            <a href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                        </div>
                        <div class="meta-data flex px-2  mb-2">
                            <span class="mr-2 text-gray-400"> <?php echo e($article->created_at->diffForHumans()); ?></span>
                            <span class="mr-2 text-gray-400"><i class="text-gray-400 fa-regular fa-clock"></i> <?php echo e($article->read_time); ?> min read</span>
                            <span class="mr-2 text-gray-400"> <i class="text-gray-400 fa-regular fa-eye"></i> <?php echo e($article->view_count); ?></span>
                        </div>
                    </div>
                    <div class="text px-2 pb-2">
                        <a href="/blog/<?php echo e($article->slug); ?>">
                            <h3 class="text-xl"><?php echo e($article->title); ?></h3>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="second-row grid grid-flow-row grid-cols-3 gap-6">
        <?php $__currentLoopData = $latestArticles->slice(2, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="old-post shadow-sm rounded-lg">
                <a href="/blog/<?php echo e($article->slug); ?>">
                    <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>" alt="<?php echo e($article->title); ?>" class="max-w-full img-box">
                </a>
                <div class="description mt-3">
                    <div class="old-tag px-1 mb-1">
                        <a href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                    </div>
                    <div class="meta-data flex px-1  mb-2">
                        <span class="mr-2 text-gray-400"> <?php echo e($article->created_at->diffForHumans()); ?></span>
                        <span class="mr-2 text-gray-400"><i class="text-gray-400 fa-regular fa-clock"></i> <?php echo e($article->read_time); ?> min read</span>
                        <span class="mr-2 text-gray-400"><i class="text-gray-400 fa-regular fa-eye"></i> <?php echo e($article->view_count); ?></span>
                    </div>
                    <div class="text px-1 pb-2">
                        <a href="/blog/<?php echo e($article->slug); ?>">
                            <h3 class="text-xl"><?php echo e($article->title); ?></h3>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/latest-posts.blade.php ENDPATH**/ ?>
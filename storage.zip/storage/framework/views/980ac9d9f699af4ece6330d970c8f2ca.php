<?php $__env->startSection('content'); ?>
	<div class="dashboard-container admin-layout">
		<div class="mx-4 py-4">
			<div class="my-8">
				<h2 class="text-2xl">My Profile</h2>
			</div>
			<div class=" space-y-6">
					<div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
						<div class="max-w-xl">
							<?php echo $__env->make('admin.profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>

					<div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
						<div class="max-w-xl">
							<?php echo $__env->make('admin.profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>

					<div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
						<div class="max-w-xl">
							<?php echo $__env->make('admin.profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>
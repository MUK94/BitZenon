<?php $__currentLoopData = $aboutSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container about">
        <div class="box">
            <div class="heading">
                <i class="fa-solid fa-graduation-cap"></i>
                <h3>Education</h3>
            </div>
            <p>
                <?php echo e($about->intro); ?></p>
        </div>
        <div class="box">
            <div class="heading">
                <i class="fa-regular fa-lightbulb"></i>
                <h3> Mission</h3>
            </div>
            <p>
                <?php echo e($about->mission); ?></p>
        </div>
        <div class="box">
            <div class="heading">
                <i class="fa-solid fa-code"></i>
                <h3>Expertise</h3>
            </div>
            <p>
                <?php echo e($about->expertise); ?></p>
        </div>
        <div class="box">
            <div class="heading">
                <i class="fa-solid fa-asterisk"></i>
                <h3> Why <?php echo e(config('app.name')); ?> ?</h3>
            </div>
            <p>
                <?php echo e($about->goal); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/about-section.blade.php ENDPATH**/ ?>
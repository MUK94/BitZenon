<div>
    
    <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class=" ml-4 text-green-600 alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <section class="bg-white dark:bg-gray-900 py-4 lg:py-8 antialiased">
        <div class="mx-auto px-4">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-lg lg:text-2xl font-bold text-gray-900 dark:text-white">Discussion (<?php echo e($commentCount); ?>)
                </h2>
            </div>

            <form wire:submit.prevent="<?php echo e($commentId ? 'update' : 'submit'); ?>" class="mb-6">
                <div
                    class="py-2 px-4 mb-4 bg-white rounded-lg border border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                    <label for="comment" class="sr-only">Your comment</label>
                    <textarea wire:model="body" id="comment" rows="3"
                        class="px-0 w-full text-sm text-gray-900 border-0 focus:ring-0 focus:outline-none dark:text-white dark:bg-gray-800"
                        placeholder="Write a comment..." required></textarea>
                </div>
                <button type="submit"
                    class="px-4 py-2 text-white custom-blue-color rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-600">
                    <?php echo e($commentId ? 'Update' : 'Comment'); ?>

                </button>
            </form>

            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="py-4 px-2 text-base bg-white rounded-lg dark:bg-gray-900">
                    <div class="flex justify-between items-center mb-2">
                        <div class="flex items-center">
                            <p
                                class="inline-flex items-center mr-3 text-sm text-gray-900 dark:text-white font-semibold">
                                <i class="fa-solid fa-user-astronaut mr-2 border rounded-full p-2"></i>
                                <strong><?php echo e($comment->user->name); ?></strong>
                            </p>
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                <?php echo e($comment->created_at->diffForHumans()); ?>

                            </p>
                        </div>

                        
                        <!--[if BLOCK]><![endif]--><?php if($comment->user_id === auth()->id()): ?>
                            <div class="nav-user-auth nav-cat-dropdown">
                                <button class="dropdown-link" onclick="event.preventDefault();">
                                    <menu class="flex items-center justify-center font-normal">
													<i class="fa-solid fa-ellipsis"></i>
                                    </menu>
                                </button>
                                <div class="dropdown-content">
                                    <ul class="drop-user bg-white rounded py-2">
                                        <li class="text-sm p-1">
                                            <a href="#" wire:click.prevent="edit(<?php echo e($comment->id); ?>)">Edit</a>
                                        </li>
                                        <li class="text-sm p-1">
                                            <a href="#"
                                                wire:click.prevent="delete(<?php echo e($comment->id); ?>)">Remove</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <p class="text-gray-500 ml-10 text-sm dark:text-gray-400">
                        <?php echo e($comment->body); ?>

                    </p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </section>
</div>


<script>
    // JavaScript to toggle dropdown
    const dropdownButton = document.getElementById('dropdownComment1Button');
    const dropdownMenu = document.getElementById('dropdownComment1');

    dropdownButton.addEventListener('click', function() {
        dropdownMenu.classList.toggle('hidden');
    });

    // Close dropdown if clicked outside
    window.addEventListener('click', function(e) {
        if (!dropdownButton.contains(e.target) && !dropdownMenu.contains(e.target)) {
            dropdownMenu.classList.add('hidden');
        }
    });
</script>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/livewire/comments.blade.php ENDPATH**/ ?>
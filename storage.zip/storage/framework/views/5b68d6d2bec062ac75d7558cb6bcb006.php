 
 <div class="testimonials my-4">
     <div class="flex items-center justify-center">
         <div class="w-full py-8 text-gray-800">
             <div class="w-full">
                 <div class="text-center max-w-xl mx-auto">
                     <h2 class="text-4xl md:text-5xl font-bold mb-5">What People <br><span>are Saying</span></h2>
                     <div class="text-center mb-10">
                         <span class="inline-block w-1 h-1 rounded-full bg-gray-500 ml-1"></span>
                         <span class="inline-block w-3 h-1 rounded-full bg-gray-500 ml-1"></span>
                         <span class="inline-block w-40 h-1 rounded-full bg-gray-500"></span>
                         <span class="inline-block w-3 h-1 rounded-full bg-gray-500 ml-1"></span>
                         <span class="inline-block w-1 h-1 rounded-full bg-gray-500 ml-1"></span>
                     </div>
                 </div>
                 <div class="-mx-3 flex items-start">
                     <div class="px-3 testimonial-layout gap-2">
                         <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div
                                 class="testimony-box w-full mx-auto h-auto rounded-lg bg-white border border-gray-200 p-5 text-gray-800 mb-6">
                                 <div class="w-full">
                                     <p class="leading-tight">
                                         <i class="secondary-color mr-1 fa-solid fa-quote-left"></i>
                                         <?php echo e($testimony->description); ?>

                                         <i class="secondary-color mr-1 fa-solid fa-quote-right"></i>
                                     </p>
                                 </div>
                                 <div class="mt-6 w-full flex mb-4 items-center">
                                     <div class="overflow-hidden rounded-full w-10 h-10 border border-gray-200">
                                         <img src="<?php echo e(asset('storage/' . $testimony->image)); ?>"
                                             alt="<?php echo e($testimony->name); ?>" class="w-10 h-10 object-cover">
                                     </div>
                                     <div class="flex-grow pl-3">
                                         <h6 class="font-bold uppercase text-gray-600">
                                             <?php echo e($testimony->name); ?></h6>
                                         <p><a href="<?php echo e($testimony->linkedin); ?>" target="_blank"
                                                 class="custom-blue-color-1 font-semibold"><?php echo e($testimony->company); ?></a>
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>

                 </div>
             </div>
         </div>
     </div>
 </div>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views/inc/testimonials.blade.php ENDPATH**/ ?>
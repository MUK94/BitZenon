@extends('layouts.app')
<title>{{ $title }} | {{ config('app.name') }} </title>
@section('content')
    <div class="content-layout">
        <div class="container article-post">
            <div class="headings">
                <h2>Professional <span>Gallery</span></h2>
            </div>
        </div>
    </div>
@endsection

<h2>New Contact Message from {{ config('app.name') }}</h2>
<p><strong>Name:</strong> {{ $data->name }}</p>
<p><strong>Email:</strong> {{ $data->email }}</p>
<p><strong>Phone:</strong> {{ $data->phone }}</p>
<p><strong>subject:</strong> {{ $data->subject }}</p>
<p><strong>Message:</strong> {{ $data->message }}</p>

<div class="social">
    <a href="https://linkedin.com/in/thierno-dev" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
    <a href="https://github.com/MUK94" target="_blank"><i class="fa-brands fa-github"></i></a>
    <a href="https://www.youtube.com/@mouctechy" target="_blank"><i class="fa-brands fa-youtube-square"></i></a>
    <a href="https://www.facebook.com/profile.php?id=61571436562286" target="_blank"><i class="fa-brands fa-facebook"></i></a>
</div>

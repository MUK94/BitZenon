<footer class="flex text-gray-600 font-light items-end justify-center bottom-0 my-2 py-2">
    © 2020 - 2024 {{ config('app.name') }} All Rights Reserved
</footer>
<script src="{{ asset('js/scripts.js') }}"></script>
<script src="{{ asset('js/graphs.js') }}"></script>

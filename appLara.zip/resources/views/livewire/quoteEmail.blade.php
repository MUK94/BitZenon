<h2>New Quote Submitted from {{ config('app.name') }}</h2>

<p><strong>Name:</strong> {{ $data->name }}</p>
<p><strong>Email:</strong> {{ $data->email }}</p>
<p><strong>Phone:</strong> {{ $data->phone }}</p>
<p><strong>Project Type:</strong> {{ $data->projectType }}</p>
<p><strong>Current State:</strong> {{ $data->projectState }}</p>
<p><strong>Scope:</strong> {{ $data->scope }}</p>
<p><strong>Description:</strong> {{ $data->description }}</p>

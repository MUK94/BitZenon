<nav class="navbar content-layout">
    
    <nav class="relative large-screen-hidden ">
        <!-- Hamburger Button -->
        <button id="menuButton" class="menu-button">
            <img src="<?php echo e(asset('bars.png')); ?>" alt="<?php echo e(config('app.name')); ?>">
        </button>

        <div id="mobileMenu"
            class="fixed z-50 top-0 left-0 h-full w-64 bg-white shadow-md transform -translate-x-full transition-transform duration-300 lg:hidden">
            <button id="closeButton" class="text-xl absolute top-4 right-4">
                <i class="fa-solid fa-times"></i>
            </button>

            <!-- Menu Links -->
            <ul class="flex flex-col space-y-12 py-12 px-12">
                <li>
                    <a href="/"
                        class="<?php echo e(request()->is('/') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Home</a>
                </li>
                <li>
                    <a href="/blog"
                        class="<?php echo e(request()->is('blog') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Blog</a>
                </li>
                <li>
                    <a href="/about"
                        class="<?php echo e(request()->is('about') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">About</a>
                </li>
                <li>
                    <a href="/services"
                        class="<?php echo e(request()->is('services') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Services</a>
                </li>
                <li>
                    <a href="/contact"
                        class="<?php echo e(request()->is('contact') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Contact</a>
                </li>
            </ul>
            <ul class="flex flex-col space-y-12 py-8 px-12">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <li><a href="/dashboard"
                                class="<?php echo e(request()->is('dashboard') ? ' text-blue-700 font-semibold' : ''); ?> ">Dashboard</a>
                        </li>
                    <?php endif; ?>
                    <div class="flex">
                        <li><a href="/admin/profile"
                                class="mt-3 mr-2 <?php echo e(request()->is('admin/profile') ? ' text-blue-800 font-semibold' : ''); ?> ">Profile</a>
                        </li> /
                        <li>
                            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                                    class="font-light ml-2">
                                    <?php echo e(__('Logout')); ?>

                                </button>
                            </form>
                        </li>
                    </div>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="nav-logo pt-1">
        <a href="/" class="logo">
            <div class="flex">
                <span class="font-bold text-4xl custom-blue-color-1 border-logo px-1">M</span>
            </div>
        </a>
    </div>
    <div class="nav-container desktop-hidden">
        <ul class="nav-links">
            <li><a href="/"
                    class="<?php echo e(request()->is('/') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Home</a>
            </li>
            <li><a href="/blog"
                    class="<?php echo e(request()->is('blog') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Blog</a>
            </li>
            <li><a href="/about"
                    class="<?php echo e(request()->is('about') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">About</a>
            </li>
            <li><a href="/services"
                    class="<?php echo e(request()->is('services') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Services</a>
            </li>
            <li><a href="/contact"
                    class="<?php echo e(request()->is('contact') ? 'border-b-2 custom-blue font-semibold' : ''); ?> hover:border-b-2 hover:border-blue-700">Contact</a>
            </li>
        </ul>
    </div>
    <div class="nav-user">
        <?php if(auth()->guard()->check()): ?>
            <div class="desktop-hidden nav-user-auth mr-3 nav-cat-dropdown">
                <button class="dropdown-link" onclick="event.preventDefault();">
                    <div class="flex items-center justify-center font-normal"><?php echo e(auth()->user()->getInitials()); ?></div> <i
                        class="text-sm fa-solid fa-angle-down"></i>
                </button>
                <ul class="dropdown-content">
                    <div class="drop-user">
                        <li><a href="/admin/profile"
                                class="mt-3 <?php echo e(request()->is('admin/profile') ? ' text-blue-800 font-semibold' : ''); ?> ">Profile</a>
                        </li>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <li><a href="/dashboard"
                                    class="<?php echo e(request()->is('dashboard') ? ' text-blue-700 font-semibold' : ''); ?> ">Dashboard</a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                                    class="font-light pb-4">
                                    <?php echo e(__('Logout')); ?>

                                </button>
                            </form>
                        </li>
                    </div>
                </ul>
            </div>
        <?php endif; ?>

        <div class="btn-booking">
            <div>
                <button wire:click.prevent="openForm" type="submit"
                    class="quoteBtn px-4 py-2 text-white custom-blue-color  rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-600">
                    <i class=" text-white pr-2 fa-solid fa-money-check-dollar"></i> Get a Quote
                </button>
            </div>
        </div>
    </div>
</nav>


<!-- JavaScript -->
<script>
    const menuButton = document.getElementById('menuButton');
    const closeButton = document.getElementById('closeButton');
    const mobileMenu = document.getElementById('mobileMenu');

    menuButton.addEventListener('click', () => {
        mobileMenu.classList.remove('-translate-x-full');
    });

    closeButton.addEventListener('click', () => {
        mobileMenu.classList.add('-translate-x-full');
    });
</script>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\layouts\navigation.blade.php ENDPATH**/ ?>
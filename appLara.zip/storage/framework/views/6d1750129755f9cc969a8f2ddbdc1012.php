<title><?php echo e($title); ?> | <?php echo e(config('app.name')); ?> </title>
<?php $__env->startSection('content'); ?>
    <div class="content-layout">
        <div class="container article-post">
            <div class="headings">
                <h2>Professional <span>Gallery</span></h2>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\pages\gallery.blade.php ENDPATH**/ ?>
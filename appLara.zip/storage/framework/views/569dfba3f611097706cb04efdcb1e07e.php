<h2>New Quote Submitted from <?php echo e(config('app.name')); ?></h2>

<p><strong>Name:</strong> <?php echo e($data->name); ?></p>
<p><strong>Email:</strong> <?php echo e($data->email); ?></p>
<p><strong>Phone:</strong> <?php echo e($data->phone); ?></p>
<p><strong>Project Type:</strong> <?php echo e($data->projectType); ?></p>
<p><strong>Current State:</strong> <?php echo e($data->projectState); ?></p>
<p><strong>Scope:</strong> <?php echo e($data->scope); ?></p>
<p><strong>Description:</strong> <?php echo e($data->description); ?></p>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\livewire\quoteEmail.blade.php ENDPATH**/ ?>
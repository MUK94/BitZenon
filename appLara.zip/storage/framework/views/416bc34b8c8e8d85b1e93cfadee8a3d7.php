<title><?php echo e($title); ?> | <?php echo e(config('app.name')); ?> </title>
<?php $__env->startSection('content'); ?>
    <div class="content-layout">
        <div class="container article-post">
            <h2>Choose Your <span>Favorite</span> Topic</h2>
            <div class="headings mb-8">
                <h3 class="text-xl custom-blue-color-1">Latest Posts</h3>
                <select name="category" id="category" class="filter-per-cat" onchange="location = this.value;">
                    <option value="/blog" <?php echo e(request()->is('blog') ? 'selected' : ''); ?>>All</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="/categories/<?php echo e($category->slug); ?>"
                            <?php echo e(request()->is('categories/' . $category->slug) ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>

                <div class="blog-old-post grid grid-flow-row grid-cols-3 gap-5 mobile">
                    <?php if($latestArticles->isEmpty()): ?>
                        <div class="alert alert-info">
                            <p class="text-red-600">No posts found for this category.</p>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $latestArticles->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="old-post shadow-sm rounded-lg">
                                <a href="/blog/<?php echo e($article->slug); ?>">
                                    <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>" alt="<?php echo e($article->title); ?>"
                                        class="max-w-full img-box">
                                </a>
                                <div class="description">
                                    <div class="old-tag px-3 mb-1">
                                        <a
                                            href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                                    </div>
                                    <div class="meta-data flex px-2  mb-2">
                                        <span class="mr-2 text-gray-400"><?php echo e($article->created_at->diffForHumans()); ?></span>
                                        <span class="mr-2 text-gray-400"><i class="text-gray-400 fa-regular fa-clock"></i>
                                            <?php echo e($article->read_time); ?> min read</span>
                                        <span class="mr-2 text-gray-400"> <i class="text-gray-400 fa-regular fa-eye"></i>
                                            <?php echo e($article->view_count); ?></span>
                                    </div>
                                    <div class="text px-2 pb-2">
                                        <a href="/blog/<?php echo e($article->slug); ?>">
                                            <h3 class="text-xl"><?php echo e($article->title); ?></h3>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="my-12 py-12">
                <h3 class="text-2xl py-6 custom-blue-color-1">Other Posts you May Like</h3>
                <div class="blog-old-post grid grid-flow-row grid-cols-3 gap-5 mobile">
                    <?php if($popularArticles->isEmpty()): ?>
                        <div class="alert alert-info">
                            <p class="text-red-600">No posts found for this category.</p>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $popularArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="old-post shadow-sm rounded-lg">
                                <a href="/blog/<?php echo e($article->slug); ?>">
                                    <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>" alt="<?php echo e($article->title); ?>"
                                        class="max-w-full img-box">
                                </a>
                                <div class="description">
                                    <div class="old-tag px-3 mb-1">
                                        <a
                                            href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                                    </div>
                                    <div class="meta-data flex px-2  mb-2">
                                        <span class="mr-2 text-gray-400"><?php echo e($article->created_at->diffForHumans()); ?></span>
                                        <span class="mr-2 text-gray-400"><i class="text-gray-400 fa-regular fa-clock"></i>
                                            <?php echo e($article->read_time); ?> min read</span>
                                        <span class="mr-2 text-gray-400"> <i class="text-gray-400 fa-regular fa-eye"></i>
                                            <?php echo e($article->view_count); ?></span>
                                    </div>
                                    <div class="text px-2 pb-2">
                                        <a href="/blog/<?php echo e($article->slug); ?>">
                                            <h3 class="text-xl"><?php echo e($article->title); ?></h3>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="pagination">
            <?php echo e($articles->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\articles\index.blade.php ENDPATH**/ ?>
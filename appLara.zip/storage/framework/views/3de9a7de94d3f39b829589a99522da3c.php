<title><?php echo e($title); ?> | Bonnafaire </title>

<?php $__env->startSection('content'); ?>

	<div class="recommended-container content-layout">
		<div class="title">
			<h2> Resultat:  <?php echo e($search); ?> <span>(<?php echo e($search_services->count()); ?>)</span> </h2>
		</div>
		<div class="container">

			<?php $__currentLoopData = $search_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="card">
					<div>
						<div class="image">
							<img src="<?php echo e(asset('storage/'.$service->cover_image)); ?>" alt="" srcset="">
						</div>
						<div class="detail">


							<a href="/categories/<?php echo e($service->slug); ?>"><span class="cat"> <?php echo e($service->category); ?></span></a>
							<h3><a href="<?php echo e(route('serviceListings.detail', ['slug'=>$service->title_slug])); ?>"><?php echo e($service->title); ?></a></h3>
							<div class="raw">
								<div class="owner">
									<img src="<?php echo e(asset('img/user.png')); ?>" alt="">
									<span><?php echo e(explode(" ", $service->user->name)[0]); ?></span>
								</div>
								<div class="review">
									<i class="fa-solid fa-star"></i><span> 5.0 (9 reviews)</span>
								</div>
							</div>
							<div class="price">
								<button href="#">A partir de <span><?php echo e($service->price); ?> FG</span></button>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\search\index.blade.php ENDPATH**/ ?>
<title><?php echo e($title); ?> | <?php echo e(config('app.name')); ?> </title>
<?php $__env->startSection('content'); ?>
    <section class="content-layout header-container">
        <div class="landing pt-6">
            <div class="left desktop-hidden">
                <?php $__currentLoopData = $heroSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="hero-container">
                        <img src="<?php echo e(asset('storage/' . $hero->image)); ?>" alt="<?php echo e($hero->title); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="right sidebar">
                <div class="slider">
                    <?php $__currentLoopData = $mostPopular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="slide">
                            <div class="box">
                                <div class="tags pb-2">
                                    <a
                                        href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                                </div>
                                <a href="/blog/<?php echo e($article->slug); ?>">
                                    <div class="side-articles side-slider">
                                        <h3><?php echo e($article->title); ?></h3>
                                        <p>
                                            <?php echo Str::limit($article->description, 50, '...'); ?>
                                        </p>
                                        <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>"
                                            alt="<?php echo e($article->title); ?>">
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- silder  buttons and dots -->
                    <button aria-label="none" class="slider__btn slider__btn--left"><i
                            class="fa-solid fa-angle-left"></i></button>
                    <button aria-label="none" class="slider__btn slider__btn--right"><i
                            class="fa-solid fa-angle-right"></i></button>

                    <div class="dots mt-2"></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-container content-layout">
        <div class="title">
            <h2>About <span>me</span></h2>
        </div>
        <div class="about-container pt-8 mb-12">
            <?php echo $__env->make('inc.about-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('inc.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <section class="section-container mb-12">
        <div class="content-layout">
            <div class="title">
                <h2>My<span> Services</span></h2>
            </div>
            <div class="service-desc text-center">
                <p class="px-4 italic text-xl ">
                    "Designed for projects of any scope and complexity, Build and enhance your web presence with tailored
                    solutions. Automate your business processes for efficiency, Turn your data into actionable insights."
                </p>
            </div>
            <?php echo $__env->make('inc.services-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>

    <section class="section-container content-layout">
        <div class="title">
            <h2> Latest <span>Posts</span></h2>
        </div>
        <div class="container posts">
            <?php echo $__env->make('inc.latest-posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\home.blade.php ENDPATH**/ ?>
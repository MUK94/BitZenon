<title><?php echo e($title); ?> | <?php echo e(config('app.name')); ?> </title>
<?php $__env->startSection('content'); ?>
    <div class="listings-container content-layout">
        <div class="detail-container">
            <div class="row flex gap-12 mobile">
                <div class="detail-col pb-12">
                    <div class="breadcumb px-2 py-1">
                        <a href="/">Home </a>
                        <i class="fa-solid fa-angle-right"></i>
                        <a href="/blog/">Articles </a>
                        <i class="fa-solid fa-angle-right"></i>
                        <span><?php echo e($article->title); ?></span>
                    </div>
                    <div class="tags mb-2">
                        <a href="/categories/<?php echo e($article->category->slug); ?>"><span><?php echo e($article->category->name); ?></span></a>
                    </div>
                    <h2 class="my-2"><?php echo e($article->title); ?></h2>
                    <div class="headlines flex items-center pb-6 mx-1 mobile">
                        <span class="text-gray-600 "> <?php echo e($article->created_at->format('F j, Y')); ?> </span>
                        <span class="mx-4 text-gray-600">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('copy-url-button', ['url' => url()->current()]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3907133486-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </span>
                    </div>
                    <div class="image-box">
                        <img src="<?php echo e(asset('storage/' . $article->cover_image)); ?>" alt="<?php echo e($article->title); ?>">
                    </div>
                    <article>
                        <?php echo $article->description; ?>

                    </article>
              
                    <div class="claps rounded">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('clap-button', ['articleId' => $article->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3907133486-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
                
                <div class="detail-sidebar">
                    <h3 class="text-xl font-semibold mx-4 text-center">Similar Articles</h3>
                    <div class="popular">
                        <?php $__currentLoopData = $similarArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="detail mb-2 border-b-2 shadow-sm rounded p-1">
                                <p class=" border-gray-300 text-gray-900">
                                    <a href="<?php echo e(route('articles.detail', ['slug' => $article->slug])); ?>"
                                        class=""><?php echo e($article->title); ?></a>
                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                    <div class="ads"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\articles\detail.blade.php ENDPATH**/ ?>
<div class="search">
	<form action="/services/search" method="GET">
		<div class="box">
			<i class="fa-solid fa-magnifying-glass"></i><input type="text" name="search" placeholder="Quoi...">
		</div>
		<button type="submit">Recherchez</button>
	</form>
</div><?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\inc\search.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin | <?php echo e(config('app.name')); ?></title>

</head>

<body>
    <div class="admin-layout">
        <div class="dashboard-container mb-8">
            
            <?php echo $__env->make('inc.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <main class="admin-content w-4/5">
                <div class="admin-navbar">
                    <?php echo $__env->make('layouts.nav-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="bg-gray-100 p-8 main-content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
    </div>
    <?php echo $__env->make('inc.admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\mklec\OneDrive\Documents\Laravel\BitZenon\resources\views\layouts\admin.blade.php ENDPATH**/ ?>